<?php
/*
* Template Name: About Page Template
*/

?>

<?php get_header(); ?>

<body <?php body_class(); ?>>
    <?php get_template_part("/template-parts/about/hero-page"); ?>

    <div class="posts">
        <?php
        while (have_posts()) :
            the_post();
        ?>
            <div class="post" <?php post_class(); ?>>
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 offset-md-1">
                            <h2 class="post-title text-center">
                                <?php the_title(); ?>
                            </h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-10 offset-md-1">
                            <p class="text-center">
                                <strong><?php the_author(); ?></strong><br />
                                <?php echo get_the_date(); ?>
                            </p>
                        </div>

                        <?php
                        if(class_exists("Attachments")){
                        $attachments = new Attachments('testimonials');
                        if (class_exists("Attachments") && $attachments->exist()) :
                        ?>
                            <div class="row">
                                <div class="col-md-8 offset-md-2">
                                    <h2 class="text-center testimonial-title">
                                        <?php _e("Testimonials", "alpha"); ?>
                                    </h2>
                                    <div class="testimonials slider text-center">
                                        <?php
                                        if (class_exists('Attachments')) {
                                            if ($attachments->exist()) {
                                        ?>
                                                <?php while ($attachment = $attachments->get()) {
                                                ?>
                                                    <div>
                                                        <?php echo $attachments->image('thumbnail'); ?>
                                                        <h4><?php echo esc_html($attachments->field('name')); ?></h4>
                                                        <p><?php echo esc_html($attachments->field('testimonial')); ?></p>
                                                        <p>
                                                            <?php echo esc_html($attachments->field('position')); ?>
                                                            <strong>
                                                                <?php echo esc_html($attachments->field('company')); ?>
                                                            </strong>
                                                        </p>
                                                    </div>
                                        <?php
                                                }
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        <?php
                        endif;
                    }
                        ?>

                        <?php
                        if(class_exists("Attachments")){
                        $attachments = new Attachments("team");
                        if (class_exists("Attachments") && $attachments->exist()) :
                        ?>
                            <div class="row">
                                <?php
                                if (class_exists('Attachments')) {
                                    if ($attachments->exist()) {
                                ?>
                                        <?php while ($attachment = $attachments->get()) {
                                        ?>
                                            <div class="col-md-4">
                                                <div class="team">
                                                    <?php echo $attachments->image('medium'); ?>
                                                    <h4><?php echo esc_html($attachments->field('name')); ?></h4>
                                                    <strong><?php echo esc_html($attachments->field('position')); ?> </strong>
                                                    <p>
                                                        <?php echo esc_html($attachments->field('bio')); ?>
                                                    </p>
                                                    <p><?php echo esc_html($attachments->field('email')); ?></p>

                                                </div>
                                            </div>
                                <?php
                                        }
                                    }
                                }
                                ?>
                            </div>
                        <?php
                        endif;
                    }
                        ?>
                        <div class="col-md-10 offset-md-1">
                            <p>
                                <?php
                                if (has_post_thumbnail()) {
                                    $thumb_url = get_the_post_thumbnail_url(null, "large");
                                    printf('<a href="%s" data-featherlight="image">', $thumb_url);
                                    the_post_thumbnail("medium-large", array("class" => "img-fluid"));
                                    echo '</a>';
                                }
                                ?>
                            </p>
                            <p>
                                <?php
                                the_content();
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <?php get_footer(); ?>