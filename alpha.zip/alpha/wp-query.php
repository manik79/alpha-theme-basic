<?php
//Template Name: Custom Query
?>
<?php get_header(); ?>

<body <?php body_class(array("our_custom_class", "myClass")); ?>>
    <?php get_template_part("/template-parts/common/hero"); ?>
    <div class="posts">
        <?php
        $_p = new WP_Query(array(
            'post__in' => array(28, 34, 38, 20),
        ));

        while ($_p->have_posts()) {
            $_p->the_post();
        ?>
            <h2 class="text-center">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
        <?php
        }
        wp_reset_query();
        ?>

    </div>
    <?php get_footer(); ?>