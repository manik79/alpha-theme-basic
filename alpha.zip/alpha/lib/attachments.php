<?php

define('ATTACHMENTS_SETTINGS_SCREEN', false); // disable the Settings screen
add_filter('attachments_default_instance', '__return_false');  // disable the default instance


function alpha_attachments($attachments)
{
    $fields  = array(
        array(
            'name'      => 'title',                         // unique field name
            'type'      => 'text',                          // registered field type
            'label'     => __('Title', 'alpha'),            // label to display
            // default value upon selection
        ),
    );


    $args = array(
        'label'         => 'Featured slider',
        'post_type'     => array('post'),
        'filetype'      => array("image"),
        'note'          => 'Add slider image',
        'button_text'   => __('Attach Files', 'alpha'),
        'fields'        => $fields,
    );

    $attachments->register('slider', $args); // unique instance name
}

add_action('attachments_register', 'alpha_attachments');

function alpha_testimonial_attachments($attachments)
{
    $fields  = array(
        array(
            'name'      => 'name',
            'type'      => 'text',
            'label'     => __('Name', 'alpha'),

        ),
        array(
            'name'      => 'position',
            'type'      => 'text',
            'label'     => __('Position', 'alpha'),

        ),
        array(
            'name'      => 'company',
            'type'      => 'text',
            'label'     => __('Company', 'alpha'),

        ),
        array(
            'name'      => 'testimonial',
            'type'      => 'textarea',
            'label'     => __('Testimonial', 'alpha'),
        ),
    );


    $args = array(
        'label'         => 'Testimonial',
        'post_type'     => array('page'),
        'filetype'      => array("image"),
        'note'          => 'Add testimonials',
        'button_text'   => __('Attach Files', 'alpha'),
        'fields'        => $fields,
    );

    $attachments->register('testimonials', $args); // unique instance name
}

add_action('attachments_register', 'alpha_testimonial_attachments');

function alpha_team_attachments($attachments)
{
    $fields  = array(
        array(
            'name'      => 'name',
            'type'      => 'text',
            'label'     => __('Name', 'alpha'),

        ),
        array(
            'name'      => 'position',
            'type'      => 'text',
            'label'     => __('Position', 'alpha'),

        ),
        array(
            'name'      => 'email',
            'type'      => 'text',
            'label'     => __('Email', 'alpha'),

        ),
        array(
            'name'      => 'bio',
            'type'      => 'textarea',
            'label'     => __('Bio', 'alpha'),
        ),
    );


    $args = array(
        'label'         => 'Team Members',
        'post_type'     => array('page'),
        'filetype'      => array("image"),
        'note'          => 'Add a team member',
        'button_text'   => __('Attach Files', 'alpha'),
        'fields'        => $fields,
    );

    $attachments->register('team', $args); // unique instance name
}

add_action('attachments_register', 'alpha_team_attachments');
