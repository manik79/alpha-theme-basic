<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <?php 
                    if(is_active_sidebar("footer_left")){
                        dynamic_sidebar("footer_left");
                    }
                ?>
            </div>
            <div class="col-md-6">
                <div class="footer-nav">
                <?php 
                    $footerMenu = array(
                        "theme_location" => "footermenu",
                        "menu_id" => "footerMenuContainer",
                        "menu_class" => "text-right"
                    );

                    wp_nav_menu($footerMenu);
                ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
